import Image from "next/image";
import {Home} from "../paths"
export default function HomePage() {
  return (
    <div>
      <Home/>
    </div>
  );
}
