import SignUp from '@/components/Auth/SignUp'
import React from 'react'

const SignupPage = () => {
  return (
    <div className='mt-5'>
      <SignUp />
    </div>
  )
}

export default SignupPage